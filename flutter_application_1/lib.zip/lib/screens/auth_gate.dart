import 'package:flutter/material.dart';

import '../main.dart';
import '../models/game_progress.dart';
import '../services/auth_service.dart';
import 'auth_screen.dart';
import 'awakening_scene_screen.dart';
import 'memory_book_registration_screen.dart';

/// Первый экран, который видит игрок при запуске приложения.
///
/// Решает, что показать:
/// - пока идёт проверка — простой лоадер;
/// - если пользователь не залогинен — экран входа/регистрации;
/// - если залогинен — восстанавливает прогресс и открывает именно то
///   место, где игрок остановился в прошлый раз: пролог на нужном
///   такте, регистрацию персонажа или сразу главное меню.
class AuthGate extends StatefulWidget {
  const AuthGate({super.key});

  @override
  State<AuthGate> createState() => _AuthGateState();
}

enum _Status { loading, needsAuth, ready }

class _AuthGateState extends State<AuthGate> {
  _Status _status = _Status.loading;
  GameProgress? _progress;

  @override
  void initState() {
    super.initState();
    _checkAuth();
  }

  Future<void> _checkAuth() async {
    final loggedIn = await AuthService.instance.isLoggedIn;
    if (!loggedIn) {
      if (mounted) setState(() => _status = _Status.needsAuth);
      return;
    }
    await _loadProgressAndReady();
  }

  Future<void> _loadProgressAndReady() async {
    final raw = await AuthService.instance.loadProgress();
    if (!mounted) return;
    setState(() {
      _progress = raw != null ? GameProgress.fromJson(raw) : null;
      _status = _Status.ready;
    });
  }

  @override
  Widget build(BuildContext context) {
    switch (_status) {
      case _Status.loading:
        return const _LoadingScreen();
      case _Status.needsAuth:
        return AuthScreen(onAuthenticated: _loadProgressAndReady);
      case _Status.ready:
        return _resolveHomeScreen();
    }
  }

  Widget _resolveHomeScreen() {
    final progress = _progress;

    if (progress == null || progress.stage == GameStage.mainMenu) {
      return const BlackScreen();
    }

    if (progress.stage == GameStage.awakening) {
      // Строится прямо здесь, как обычный дочерний виджет (а не через
      // Navigator.push) — поэтому context этого State остаётся живым
      // всё время, пока показан этот экран, и использовать его в
      // _goToRegistration ниже безопасно.
      return AwakeningSceneScreen(
        initialBeatIndex: progress.beatIndex,
        initialPageIndex: progress.pageIndex,
        onFinished: _goToRegistration,
      );
    }

    // GameStage.registration — игрок дошёл до регистрации персонажа,
    // но не завершил её.
    return MemoryBookRegistrationScreen(onComplete: _completeRegistration);
  }

  void _goToRegistration() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        // Как и в BookOpeningVideoScreen: используем ctx нового
        // экрана, а не context этого состояния — после pushReplacement
        // AuthGate будет уничтожен, и его context станет невалидным
        // к моменту, когда реально вызовется onComplete.
        builder: (ctx) => MemoryBookRegistrationScreen(
          onComplete: (data) => _completeRegistrationWithCtx(ctx, data),
        ),
      ),
    );
  }

  void _completeRegistration(MemoryBookRegistrationData data) {
    // Этот путь вызывается, когда MemoryBookRegistrationScreen построен
    // прямо в _resolveHomeScreen (AuthGate ещё не заменён Navigator'ом),
    // поэтому context здесь ещё валиден.
    _completeRegistrationWithCtx(context, data);
  }

  void _completeRegistrationWithCtx(
    BuildContext ctx,
    MemoryBookRegistrationData data,
  ) {
    AuthService.instance.saveProfile(data.toJson());
    AuthService.instance.saveProgress(
      GameProgress(stage: GameStage.mainMenu).toJson(),
    );
    Navigator.of(ctx).pushReplacement(
      MaterialPageRoute(builder: (_) => const BlackScreen()),
    );
  }
}

class _LoadingScreen extends StatelessWidget {
  const _LoadingScreen();

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFF0A1030),
      body: Center(
        child: CircularProgressIndicator(color: Color(0xFFE8C878)),
      ),
    );
  }
}
